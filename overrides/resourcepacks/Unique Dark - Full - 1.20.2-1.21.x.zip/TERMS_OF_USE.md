Copyright &copy; Unique Dark

Author AmongstReality

Links to pages of the author on different platforms:

- [Patreon](https://www.patreon.com/c/AmongstReality)
- [BuyMeACoffee](https://www.buymeacoffee.com/amongstreality)
- [CurseForge](https://www.curseforge.com/members/amongstreality/projects)
- [Modrinth](https://modrinth.com/user/AmongstReality)
- [Planet Minecraft](https://www.planetminecraft.com/member/amongstreality/)

When you can use my assets:

- If you want to add mod support as an addon for the resource pack. If you do that, you have to add clear credit that
  includes links to the original resource pack.
- Any private modifications of the original resource pack.

When you can **NOT** use my assets:

- Distribution on the Bedrock Marketplace.
- Locking behind a paywall (e.g. Patreon).
- Distribution of original/modified assets on any platforms.

Links to the resource pack's pages on different platforms:

- [CurseForge](https://www.curseforge.com/minecraft/texture-packs/unique-dark)
- [Modrinth](https://modrinth.com/resourcepack/unique-dark)
